"""Watcher utilities for background monitoring."""

